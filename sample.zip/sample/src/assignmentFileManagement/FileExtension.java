//2. Write a Java program to get specific files by extensions from a specified folder.

package assignmentFileManagement;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FileExtension {

	public static void main(String[] args) {
		String directoryPath = "/home/vineethvenu/eclipse-workspace/sample/";
		String[] extensions = { "txt", "pdf", "docx" };
		List<File> files = getFilesWithExtensions(directoryPath, extensions);
		if (files != null && !files.isEmpty()) {
			System.out.println("Files with specified extensions in " + directoryPath + ":");
			for (File file : files) {
				System.out.println(file.getName());
			}
		} else {
			System.out.println("No files with specified extensions found in " + directoryPath);
		}
	}

	public static List<File> getFilesWithExtensions(String directoryPath, String[] extensions) {
		List<File> result = new ArrayList<>();
		File directory = new File(directoryPath);
		File[] files = directory.listFiles();
		if (directory.exists() && directory.isDirectory()) {
			if (files != null) {
				for (File file : files) {
					for (String extension : extensions) {
						if (file.getName().toLowerCase().endsWith("." + extension)) {
							result.add(file);
							break;
						}
					}
				}
			}
		} else {
			System.out.println("The specified path is not a directory or does not exist.");
		}
		return result;
	}
}
