//3. Write a Java program to check if a file or directory specified by pathname exists or not.

package assignmentFileManagement;

import java.io.File;

public class FileSreaching {

	public static void main(String[] args) {
		String path = "/home/vineethvenu/eclipse-workspace/sample/";
		File file = new File(path);
		if (file.exists()) {
			if (file.isFile()) {
				System.out.println(file + " exist " + file.getAbsolutePath());
			} else if (file.isDirectory()) {
				System.out.println("Directory exists: " + file.getAbsolutePath());
			} else {
				System.out.println("Exists, but not a regular file or directory: " + file.getAbsoluteFile());
			}
		} else {
			System.out.println("File or directory does not exist: " + file.getAbsolutePath());
		}
	}
}
