//4. Write a Java program to check if a file or directory has read and write permission.


package assignmentFileManagement;

import java.io.File;

public class FilePermission {

	public static void main(String[] args) {
		String path="/home/vineethvenu/eclipse-workspace/sample/";
		File fileIo=new File(path);
		if (fileIo.exists()) {
			if (fileIo.canRead()) {
				System.out.println(fileIo.getAbsolutePath()+" has a read permission");
			} else {
				System.out.println(fileIo.getAbsolutePath()+"does not a read permission");
			}if (fileIo.canWrite()) {
				System.out.println(fileIo.getAbsolutePath()+"has writting permission");
			}else {
				System.out.println(fileIo.getAbsolutePath()+"does not have a write permission");
			}
		}
	}

}
