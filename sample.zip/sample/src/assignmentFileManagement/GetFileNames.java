//1. Write a Java program to get a list of all file/directory names from the given.

package assignmentFileManagement;

import java.io.File;

public class GetFileNames {

	public static void main(String[] args) {
		
		  String directoryPath = "/home/vineethvenu/eclipse-workspace/";

	        // Create a File object for the directory
	        File directory = new File(directoryPath);

	        // Get the list of all files and directories
	        if (directory.exists() && directory.isDirectory()) {
	            String[] fileList = directory.list();
	            
	            // Check if the directory is empty
	            if (fileList != null && fileList.length > 0) {
	                System.out.println("List of files and directories in " + directoryPath + ":");
	                
	                for (String fileName : fileList) {
	                    System.out.println(fileName);
	                }
	            } else {
	                System.out.println("The directory is empty.");
	            }
	        } else {
	            System.out.println("The specified path is not a directory or does not exist.");
	        }

	}

}
