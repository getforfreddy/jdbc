package oops;

public class Student {

	String name;
	int id;

	void study() {
		System.out.println("Student is styding ....");
	}

	void reading() {
		// TODO Auto-generated method stub
System.out.println("reading.....");
	}

}
