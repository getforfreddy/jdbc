package oops;

public class BCAStudent extends Student{
@Override
void reading() {
	// TODO Auto-generated method stub
	System.out.println("BCA student is reading java book");
}
}
