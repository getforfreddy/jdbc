package oops;

public class TestStudent {
public static void main(String[] args) {
	BCAStudent bcaStudent=new BCAStudent();
	bcaStudent.reading();
}
}
