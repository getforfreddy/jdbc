package oops;

public class Employee {
	String name;
	String id;
	Address address;
	public Employee() {
		super();
	}
	public Employee(String name, String id, Address address) {
		super();
		this.name = name;
		this.id = id;
		this.address = address;
	}
	void display()
	{
		System.out.println(name);
		System.out.println(id);
		System.out.println(address.city+" "+address.state+" "+address.country);
	}
	

}
