package oops;

public class TestAddress {
	public static void main(String[] args) {
		Address address1=new Address("Kochi", "Kerala", "India");
		Address address2=new Address("EKM", "Kerala", "India");
		
		
		Employee employee=new Employee("Freddy", "57656", address2);
		employee.display();

	}

}
