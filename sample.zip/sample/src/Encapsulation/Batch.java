package Encapsulation;

public class Batch {
public static void main(String[]args) {
	Student student= new Student();
	student.setName("Sharon");
	System.out.println(student.getName());
}
}
