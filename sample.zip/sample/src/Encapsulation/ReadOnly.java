package Encapsulation;

public class ReadOnly {
	private String college="AKG";  
	//getter method for college  
	public String getCollege(){  
	return college;  
	}  
}
