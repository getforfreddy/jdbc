package Encapsulation;

public class WriteOnly {
	private String college;  
	//getter method for college  
	public void setCollege(String college){  
	this.college=college;  
	} 
}
