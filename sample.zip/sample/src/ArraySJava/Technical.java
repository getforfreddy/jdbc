package ArraySJava;

public class Technical {
	public static void main(String[] args) {
		String[] name = new String[4];
		name[0] = "Karthi";
		name[1] = "Maneesha";
		name[2] = "Sreelakshmi";
		name[3] = "Jiji";
		for (int i = 0; i < name.length; i++) {
			System.out.println("Technical branch "+name[i]);
		}
	}

}
