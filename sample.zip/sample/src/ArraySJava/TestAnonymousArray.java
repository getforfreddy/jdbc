package ArraySJava;

public class TestAnonymousArray {
	static void printAnonymous(int arr[]) {
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printAnonymous(new int[]{12,32,51,10});
	}

}
