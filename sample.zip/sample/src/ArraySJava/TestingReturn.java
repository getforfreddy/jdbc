package ArraySJava;

public class TestingReturn {
	static int[] geet() {
		return new int[] { 20, 22, 23, 21, 25 };
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num[] = geet();
		for (int i = 0; i < num.length; i++) {
			System.out.println("Tokens are: "+num[i]);
		}
	}

}
//package ArraySJava;
//
//public class TestingReturn {
//    static int[] geet() {
//        return new int[]{20, 22, 23, 21, 25};
//    }
//
//    public static void main(String[] args) {
//        int num[] = geet();
//        for (int i = 0; i < num.length; i++) {
//            System.out.println(num[i]);
//        }
//    }
//}
