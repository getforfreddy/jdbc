package ArraySJava;

public class TestForEach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] room= {21,23,22,25,24};
		for(int i:room) {
			System.out.println("Rooms are: "+i);
		}
	}

}
