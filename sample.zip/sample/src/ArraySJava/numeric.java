package ArraySJava;

public class numeric {

	public static void main(String[] args) {
		int[] number= {20,22,21,24};
		// TODO Auto-generated method stub
		for (int i = 0; i < number.length; i++) {
			System.out.println(number[i]);
		}
	}

}
