package ArraySJava;

public class MultiDiamensionalArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nameAndDetails[][]= {{"Karthik","Maneesha","Pranav"},{"20","26","20"},{"DM","DM","Video Editer"}};
		for(int i=0; i<3;i++) {
			for(int j=0;j<3;j++ ) {
				System.out.print(nameAndDetails[i][j]+" ");
			}
		}
	System.out.println();
	}

}
