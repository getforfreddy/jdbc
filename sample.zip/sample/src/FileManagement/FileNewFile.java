package FileManagement;


import java.io.File;

public class FileNewFile {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		String path = "";
		Boolean boolean1 = false;
		Boolean deleted = false;
		try {
			File file = new File("testingFile.txt");
			file.createNewFile();
			System.out.println(file);
			File file2 = file.getCanonicalFile();
			System.out.println(file2);
			boolean1 = file2.exists();
			path = file2.getAbsolutePath();
			System.out.println(boolean1);
			if (boolean1) {
				System.out.println(path + "Exist?" + boolean1);
			}
//			file.delete();
//			deleted=file.exists();
//			if (!deleted) {
//				System.out.println("File Deleted");
//			}
//			else {
//				System.out.println("File not deleted");
//			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
