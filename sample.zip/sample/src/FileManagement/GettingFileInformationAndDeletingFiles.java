//package FileManagement;
//
//import java.io.File;
//
//
//public class GettingFileInformationAndDeletingFiles {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		File f0=new File("DeletingFile.txt");
//		if (f0.exists()) {
//			System.out.println("File "+f0+" created successfuly");
//			System.out.println("Path "+f0.getAbsolutePath());
//			if(f0.delete()) {
//				System.out.println(f0+" is deleted successfuly");
//			}
//			
//		} else {
//			System.out.println("something went wrong");
//
//		}
//	}
//
//}




package FileManagement;

import java.io.File;
import java.io.IOException;

public class GettingFileInformationAndDeletingFiles {

    public static void main(String[] args) {
        // Define the file
        File f0 = new File("DeletingFile.txt");
        
        try {
            // Attempt to create the file
            if (f0.createNewFile()) {
                System.out.println("File " + f0 + " created successfully");
            } else {
                System.out.println("File " + f0 + " already exists");
            }
            
            // Display file information
            if (f0.exists()) {
                System.out.println("File name: " + f0.getName());
                System.out.println("Absolute path: " + f0.getAbsolutePath());
                System.out.println("Writeable: " + f0.canWrite());
                System.out.println("Readable: " + f0.canRead());
                System.out.println("File size in bytes: " + f0.length());
            }
            
            // Delete the file
//            if (f0.delete()) {
//                System.out.println("File " + f0 + " deleted successfully");
//            } else {
//                System.out.println("Failed to delete the file " + f0);
//            }
//            
        } catch (IOException e) {
            // Handle potential IOException
            System.out.println("An error occurred");
            e.printStackTrace();
        }
    }
}
