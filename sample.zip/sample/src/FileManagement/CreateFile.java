
package FileManagement;

import java.io.File;

public class CreateFile {

	public static void main(String[] args) {
		// Specify the file path
		try {
			File f0 = new File("/home/vineethvenu/Desktop/Freddy Nixal_Workfolder/studyMaterials:CreatingFiles");
			// Check if the file exists and print its details
			if (f0.exists()) {
				System.out.println("Name of the file is: " + f0.getName());
				System.out.println("The path of the file is: " + f0.getAbsolutePath());
				System.out.println("Is file writable: " + f0.canWrite());
				System.out.println("Is file readable: " + f0.canRead());
				System.out.println("The size of the file is: " + f0.length() + " bytes");
			} else {
				System.out.println("The file does not exist");
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("File not created");
		}
	}
}
