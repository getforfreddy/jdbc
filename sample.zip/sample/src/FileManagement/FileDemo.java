package FileManagement;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File file=new File("JavaDemoFile.txt");
			if (file.createNewFile()) {
				System.out.println("New file is created");
			}
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
