//package Interface;
//
//interface Members {
//	String members();
//}
//
//class father implements Members {
//	public String members() {
//		return "Father";
//	}
//}
//
//class mother implements Members {
//	public String members() {
//		return "Mother";
//	}
//}
//
//class youngerBrother implements Members {
//	public String member() {
//		return "Younger Brother";
//	}
//}
//
//class youngerSister implements Members {
//	public String member() {
//		return "Younger Sister";
//	}
//}
//
//class elderBrother implements Members {
//	public String member() {
//		return "Elder Brother";
//	}
//}
//
//class elderSister implements Members {
//	public String member() {
//		return "Elder Sister";
//	}
//}
//
//class Family {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Members person = new father();
//		Members person2 = new mother();
//		Members person3 = new youngerBrother();
//		Members person4 = new youngerSister();
//		Members person5 = new elderBrother();
//		Members person6 = new elderSister();
//		System.out.println(person.members());
//		System.out.println(person2.members());
//		System.out.println(person3.members());
//		System.out.println(person4.members());
//		System.out.println(person5.members());
//		System.out.println(person6.members());
//	}
//
//}

package Interface;

interface Members {
    String members();
}

class father implements Members {
    public String members() {
        return "Father";
    }
}

class mother implements Members {
    public String members() {
        return "Mother";
    }
}

class youngerBrother implements Members {
    public String members() { // corrected method name
        return "Younger Brother";
    }
}

class youngerSister implements Members {
    public String members() { // corrected method name
        return "Younger Sister";
    }
}

class elderBrother implements Members {
    public String members() { // corrected method name
        return "Elder Brother";
    }
}

class elderSister implements Members {
    public String members() { // corrected method name
        return "Elder Sister";
    }
}

class Family {

    public static void main(String[] args) {
        Members person = new father();
        Members person2 = new mother();
        Members person3 = new youngerBrother();
        Members person4 = new youngerSister();
        Members person5 = new elderBrother();
        Members person6 = new elderSister();
        
        System.out.println(person.members());
        System.out.println(person2.members());
        System.out.println(person3.members());
        System.out.println(person4.members());
        System.out.println(person5.members());
        System.out.println(person6.members());
    }
}

