package Interface;

interface Printable {
	void print();
}

interface Showaeble extends Printabe {
	void show();
}

class InterfaceInheritance implements Showaeble {
	public void print() {
		System.out.println("Hello");
	}

	public void show() {
		System.out.println("Welcome");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceInheritance test = new InterfaceInheritance();
		test.print();
		test.show();

	}

}
