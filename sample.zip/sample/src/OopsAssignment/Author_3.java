package OopsAssignment;

public class Author_3 {
	private String name;
	private String email;
	private char gender;
	public Author_3(String name, String email, char gender) {
		super();
		this.name = name;
		this.email = email;
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public char getGender() {
		return gender;
	}
	public String toString() {
		return name+" ("+gender+") at"+email;
	}
}
