/*It contains: Two private variables: accountNumber (int) and balance (double), which maintains the current 
 * account balance.Public methods credit() and debit(), which adds or subtracts the given amount
 *  from the balance, respectively. The debit() method shall print "amount withdrawn exceeds 
 *  the current balance!" if amount is more than balance.A toString(),which returns 
 *  "A/C no: xxx Balance=xxx" (e.g., A/C no: 991234 Balance=$88.88), with balance rounded 
 *  to two decimal places.*/


package OopsAssignment;

public class Account {
    private int accountNumber = 303666412; 
    private double balance = 35000;

    public void credit(double amount) {
        if (amount > 0.0) {
            balance += amount;
        }
    }

    public void debit(double amount) {
        if (amount > balance) {
            System.out.println("Amount withdrawn exceeds the current balance!");
        } else {
            balance -= amount;
        }
    }

    public double getBalance() {
        return balance;
    }

    public String toString() {
        return "A/C no: " + accountNumber + " Balance=$" + String.format("%.2f", balance);
    }

    public static void main(String[] args) {
        // Create an Account object with an initial balance
        Account account1 = new Account();
        
        // Display initial balance
        System.out.println("Initial balance: $" + account1.getBalance());

        // Test credit method
        account1.credit(200.0);
        System.out.println("Balance after crediting $20: $" + account1.getBalance());

        // Test debit method with an amount less than the balance
        account1.debit(30000.0);
        System.out.println("Balance after debiting $30: $" + account1.getBalance());

        // Test debit method with an amount greater than the balance
        account1.debit(500000.0);
        System.out.println("Balance after attempting to debit $50: $" + account1.getBalance());

        // Test toString method
        System.out.println(account1.toString());
    }
}
