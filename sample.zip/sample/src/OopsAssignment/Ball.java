/*A Ball class models a moving ball contains the following members:

Two private variables x, y, which maintain the position of the ball.
Constructors, public getters and setters for the private variables.
A method setXY(), which sets the position of the ball and setXYSpeed() 
to set the speed of the ball.A method move(), which increases x and y by the 
given xDisp and yDisp, respectively.A toString(), which returns "Ball @ (x,y)".*/


package OopsAssignment;

public class Ball {
		private double x;
        private double y; 

    public Ball() {
        this.x = 0;
        this.y = 0;
    }

    public Ball(double x, double y) {
        this.x = x;
        this.y = y;
    }

        public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

        public void setXY(double x, double y) {
        this.x = x;
        this.y = y;
    }

        public void setXYSpeed(double xDisp, double yDisp) {
    }

        public void move(double xDisp, double yDisp) {
                this.x += xDisp;
        this.y += yDisp;
    }

        @Override
    public String toString() {
        return "Ball @ (" + x + "," + y + ")";
    }

        public static void main(String[] args) {
        Ball ball = new Ball(10, 15);
        System.out.println(ball); 

        ball.move(5, -3);
        System.out.println(ball); 

        ball.setXY(20, 30);
        System.out.println(ball); 
    }
}

