//package OopsAssignment;
//
//public class Book {
//	    // Private member variables
//	    private String name;
//	    private Author author;
//	    private double price;
//	    private int qtyInStock;
//	    
//	    // Constructors
//	    public Book(String name, Author author, double price, int qtyInStock) {
//	        this.name = name;
//	        this.author = author;
//	        this.price = price;
//	        this.qtyInStock = qtyInStock;
//	    }
//	    
//	    public Book(String name, Author author, double price) {
//	        this(name, author, price, 0); // Default qtyInStock is 0
//	    }
//	    
//	    // Getters and setters
//	    public String getName() {
//	        return name;
//	    }
//	    
//	    public Author getAuthor() {
//	        return author;
//	    }
//	    
//	    public double getPrice() {
//	        return price;
//	    }
//	    
//	    public void setPrice(double price) {
//	        this.price = price;
//	    }
//	    
//	    public int getQtyInStock() {
//	        return qtyInStock;
//	    }
//	    
//	    public void setQtyInStock(int qtyInStock) {
//	        this.qtyInStock = qtyInStock;
//	    }
//	    
//	    // toString() method
//	    @Override
//	    public String toString() {
//	        return "'" + name + "' by " + author.toString();
//	    }
//	}
//
