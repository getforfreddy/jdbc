package inheritance;

public class EmployeePosition extends Employee{
	public static void main(String args[]) {
		EmployeePosition employeePosition=new EmployeePosition();
		employeePosition.Employee();
		employeePosition.company();
	
	}
}
