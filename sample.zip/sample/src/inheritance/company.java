package inheritance;

public class company {
	String company="Spectrum";
	void company() {
//		System.out.println(company);
	}
}
