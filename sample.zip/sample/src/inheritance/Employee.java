package inheritance;

public class Employee extends company {

	void Employee() {
		String name="Freddy";
		System.out.println("Name of the emplyeee is:"+name);
		System.out.println("name of the company is:"+company);
	}
	
	

}
