package inheritance;

public class TechincalDepartment extends company{
	void department() {	
		
	}
}
