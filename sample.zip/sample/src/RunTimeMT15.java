
class RunTimeMT15 extends RunTimeBike {
	void Mt() {
		System.out.println("MT15 is running speed of 90km/hr");
	}
}
