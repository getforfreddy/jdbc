package Packages;

public class UsingPackageName {
	public static void main(String args[]){  
		System.out.println("Welcome to package");  
       }  
}

