package AbstractClassmethod;
abstract class Shape{
	abstract void draw();

}
class Square extends Shape{
	void draw() {
		System.out.println("Drawing Square");
	}
}
class Rectangle extends Shape{
	void draw() {
		System.out.println("Drawing Rectangle");
	}
}
class Circle extends Shape{
	void draw() {
		System.out.println("Drawing Circle");
	}
}
 class CircleShape {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape circleShape = new Circle();
		Shape squareShape = new Square();
		Shape rectangleShape = new Rectangle();
		circleShape.draw();
//		squareShape.draw();
//		rectangleShape.draw();

	}
 }
