package AbstractClassmethod;
abstract class Bike{
	abstract void run();
}
class Abstract extends Bike {
	void run() {
		System.out.println("running safely in 40km/hr");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bike bike=new Abstract();
		bike.run();
	}

}
