package String;

public class ClassByNewKeyWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String word="Words";
		char character[]= {'w','o','r','d'};
		String stringword= new String(character);
		String charword=new String("New Word");
		System.out.println(word);
		System.out.println(stringword);
		System.out.println(charword);
	} 

}
