package String;

public class TestStringComparion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name1= "Freddy";
		String name2= "freddy";
		String name3= "Freddy Nixal";
		String name4=new String("Freddy");
		String name5= "Nixal";
		System.out.println(name1.equals(name2));
		System.out.println(name3.equals(name5));
		System.out.println(name4.equals(name1));
		System.out.println(name4.equals(name2));
	}

}
