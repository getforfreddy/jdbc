package String;

public class TestImmutableString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String count="Freddy";
		count=count.concat(" Nixal");
		System.out.println(count);
	}

}
