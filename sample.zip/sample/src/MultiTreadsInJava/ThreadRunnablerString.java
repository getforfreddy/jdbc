package MultiTreadsInJava;

public class ThreadRunnablerString implements Runnable{
	public void run() {
		System.out.println("Now the thread is runnable");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable ru= new ThreadRunnablerString();
		Thread trs=new Thread(ru, "My new thread");
		trs.start();
		String str=trs.getName();
		System.out.println(str);
	}

}
