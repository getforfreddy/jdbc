package MultiTreadsInJava;

class Multy implements Runnable{
	public void run() {
		System.out.println("Thread is running..........");		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Multy multy= new Multy();
		Thread t1= new Thread(multy);
		t1.start();
				
	}

}
