
//class RunTimeRunning extends RunTimeMT15{
//	public static void Main(String[] args) {
//		RunTimeRunning bikes= new RunTimeRunning();
//		bikes.Mt();
//	}
//
//}
class RunTimeRunning extends RunTimeMT15 {
    public static void main(String[] args) {
        RunTimeRunning bikes = new RunTimeRunning();
        bikes.Bike(); // This will call the method from RunTimeBike
        bikes.Mt();   // This will call the method from RunTimeMT15
    }
}