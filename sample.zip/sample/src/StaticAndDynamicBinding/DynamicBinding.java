//package StaticAndDynamicBinding;
//
//class Door {
//	void closeed() {
//		System.out.println("Door is colsed");
//	}
//}
//
//class window extends Door {
//	void Opened() {
//		System.out.println("Window is opened");
//	}
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Door op = new Door();
//		op.closeed();
//	}
//
//}
package StaticAndDynamicBinding;

class Door {
    void closed() {
        System.out.println("Door is closed");
    }
}

class Window extends Door {
    @Override
    void closed() {
        System.out.println("Window is closed");
    }

    void opened() {
        System.out.println("Window is opened");
    }

    public static void main(String[] args) {
        // Static binding
        Door door = new Door();
        door.closed();

        // Dynamic binding
        Door dynamicWindow = new Window();
        dynamicWindow.closed();

        // Specific method of Window class
        Window window = new Window();
        window.opened();
    }
}
