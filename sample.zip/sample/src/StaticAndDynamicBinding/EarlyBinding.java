package StaticAndDynamicBinding;

class Room {
	void enter() {
		System.out.println("A person entered into room");
	}
}

public class EarlyBinding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Room R1 = new Room();
		R1.enter();
	}

}
//package StaticBinding;
//
//class Room {
//    public void enter() {
//        System.out.println("A person entered into room");
//    }
//}
//
//public class EarlyBinding {
//
//    public static void main(String[] args) {
//        Room R1 = new Room();
//        R1.enter();
//    }
//}
