//6.Write a Java program to print the sum (addition), multiply, subtract, divide and remainder of two numbers.
//Test Data:
//Input first number: 125
//Input second number: 24

package sample;

public class Assignment6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=125;
		int b=24;
		int sum=a+b;
		int dif= a-b;
		int mul= a*b;
		int div= a/b;
		int mod= a%b;
		System.out.println("125+24 = "+sum);
		System.out.println("125-24 = "+dif);
		System.out.println("125*24 = "+mul);
		System.out.println("125/24 = "+div);
		System.out.println("125%24 = "+mod);
	}

}
