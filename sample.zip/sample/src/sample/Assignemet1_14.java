//14.Write a program to convert given no. of days into months and days.(66 days contain 2 months and 6 days)

package sample;

public class Assignemet1_14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int days = 60;
		int[] result = daysToMonthsAndDays(days);
		int months = result[0];
		int remainingDays = result[1];

		System.out.println(days + " days contain " + months + " months and " + remainingDays + " days.");
	}

	public static int[] daysToMonthsAndDays(int days) {
		int months = days / 30; // Assuming each month has 30 days
		int remainingDays = days % 30;
		int[] result = { months, remainingDays };
		return result;
	}

}
