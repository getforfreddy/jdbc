package sample;
class Arithmetics {
 public int add(int a, int b) {
     return a + b;
 }
 public int subtract(int a, int b) {
     return a - b;
 }
 public int multiply(int a, int b) {
     return a * b;
 }
 public double divide(int a, int b) {
     if (b != 0) {
         return (double) a / b;
     } else {
         throw new IllegalArgumentException("Cannot divide by zero");
     }
 }
}
public class ToTestInt1_2_9 {
	 private Arithmetics arithmetics;

	    public ToTestInt1_2_9() {
	        this.arithmetics = new Arithmetics();
	    }
	    public void testOperations(int a, int b) {
	        System.out.println("Addition of " + a + " and " + b + ": " + arithmetics.add(a, b));
	        System.out.println("Subtraction of " + a + " and " + b + ": " + arithmetics.subtract(a, b));
	        System.out.println("Multiplication of " + a + " and " + b + ": " + arithmetics.multiply(a, b));
	        try {
	            System.out.println("Division of " + a + " and " + b + ": " + arithmetics.divide(a, b));
	        } catch (IllegalArgumentException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	    public static void main(String[] args) {
	        ToTestInt1_2_9 tester = new ToTestInt1_2_9();
	        tester.testOperations(10, 5);
	    }
}
