package sample;

public class Example1 {

	public static void main(String[] args) {
		int num1= 110;
		int num2= 103;
		int sum=num1+num2;
		int dif= num1-num2;
		int mul =num1*num2;
		int div= num1/num2;
		int mod=num1%num2;
//		int indev= num1 ~/ num2;
		System.out.println("sum is:" +sum);
		System.out.println("difference is:"+dif);
		System.out.println("multiplication is:"+mul);
		System.out.println("divition is:"+div);
		System.out.println("Moduluation is:"+mod);
		System.out.println(num1==num2);
		System.out.println(num1<num2);
		System.out.println(num1>num2);
		System.out.println(num1<=num2);
		System.out.println(num1>=num2);
		System.out.println(num1!=num2);
		System.out.println("num1 = "+num1);
		System.out.println("num1+1 ="+num1++);
		System.out.println(num1++);
		System.out.println("num2 = "+num2);
		System.out.println("num2-1 = "+--num2);
	}

}
