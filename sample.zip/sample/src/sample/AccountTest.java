package sample;

public class AccountTest {
    public static void main(String[] args) {
        // Create an Account object with an initial balance
        Account account1 = new Account(50.0);
        
        // Display initial balance
        System.out.println("Initial balance: $" + account1.getBalance());

        // Test credit method
        account1.credit(20.0);
        System.out.println("Balance after crediting $20: $" + account1.getBalance());

        // Test debit method with an amount less than the balance
        account1.debit(30.0);
        System.out.println("Balance after debiting $30: $" + account1.getBalance());

        // Test debit method with an amount greater than the balance
        account1.debit(50.0);
        System.out.println("Balance after attempting to debit $50: $" + account1.getBalance());
    }
}
