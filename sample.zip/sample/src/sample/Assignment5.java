//5.Write a Java program that takes two numbers as input and display the product of two numbers.
//Test Data:
//Input first number: 25
//Input second number: 5


package sample;

public class Assignment5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number1=25;
		int number2=5;
		int mul=number1*number2;
		System.out.println("25x5 = "+mul);

	}

}
