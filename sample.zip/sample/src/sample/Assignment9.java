//9.Write a Java program to compute a specified formula.
//4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11))

package sample;

public class Assignment9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11)));
		

	}

}
