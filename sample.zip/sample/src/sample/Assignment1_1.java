//1.Write a program to check whether the entered number is postive or negative

package sample;

public class Assignment1_1 {

	public static void main(String[] args) {
		int num = -1;
		if(num<0) {
			System.out.println("entered number is negative");
		}
		else {
			System.out.println("Entered number is postive");
		}
	}

}
