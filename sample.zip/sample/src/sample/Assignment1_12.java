//12.Write a program to Display Multiplication Table

package sample;

public class Assignment1_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=3;
		for(int i=1;i<=10;i++) {
			int mul=num*i;
			System.out.println(num+" x "+i+" = "+mul);
		}
	}

}
