//10.Write a program to Check if a number is Palindrome Number

package sample;

public class Assignment1_10 {
	   public static boolean isPalindrome(int num) {
	        return isPalindromeRecursive(num, 0);
	    }
	    public static boolean isPalindromeRecursive(int n, int rev) {
	        if (n < 10) {
	            return rev * 10 + n == n;
	        } else {
	            int lastDigit = n % 10;
	            rev = rev * 10 + lastDigit;
	            return isPalindromeRecursive(n / 10, rev);
	        }
	    }	 
	    public static void main(String[] args) {
	        int number = 12321;
	        if (isPalindrome(number)) {
	            System.out.println(number + " is a palindrome number.");
	        } else {
	            System.out.println(number + " is not a palindrome number.");
	        }
	    }
}
