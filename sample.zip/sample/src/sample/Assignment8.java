//8.Write a Java program to compute the specified expressions and print the output.
//Test Data:
//((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5)) 


package sample;

public class Assignment8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));

	}

}
