//Create a class Dog, that has 3 properties (class fields) breed, age and colour with behaviours (class method) bark and sleep.

package sample;

class Dog{
	private int age;
	private String breed;
	private String color;
	
	public Dog(int age, String breed, String color) {
		this.age=age;
		this.breed=breed;
		this.color=color;
	}
	public int getAge(){
		return age;
	}
	public void setage(int age) {
		this.age=age;
	}
	public String getBreed(){
		return breed;
	}
	public void setBreed(String breed) {
		this.breed=breed;
	}
	public String getColor(){
		return color;
	}
	public void setcolor(String breed) {
		this.color=color;
	}
	public void Bark() {
		System.out.println("woof.. Woof");	
	}
	public void sleeps() {
		System.out.println("Zzz... Zzz....");	
	}
}
public class Assignment1_2_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog myDog = new Dog(5,"Labrador","Yellow");

        // Displaying the properties
        System.out.println("Breed: " + myDog.getBreed());
        System.out.println("Age: " + myDog.getAge());
        System.out.println("Color: " + myDog.getColor());

        // Calling the behaviors
        myDog.Bark();
        myDog.sleeps();

	}

}
