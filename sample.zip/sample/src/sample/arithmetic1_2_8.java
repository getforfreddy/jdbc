/*Write a program to create interface named test. In this interface the member function is 
 * square. Implement this interface in arithmetic class.*/

package sample;

interface Test {
	void square(int num);
}

class Arithmetic implements Test {
	@Override
	public void square(int num) {
		System.out.println("The square of " + num + " is " + (num * num));
	}
}

public class arithmetic1_2_8 {

	public static void main(String[] args) {
		Arithmetic arithmetic = new Arithmetic();
		arithmetic.square(5);
	}

}
