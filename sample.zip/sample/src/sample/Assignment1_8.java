//8.Write a program for Printing Odd numbers between 1 and 50

package sample;

public class Assignment1_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 50; i += 2) {
            System.out.println(i);
        }
	}

}
