//7.Write a program to generate even Numbers

package sample;

public class Assignment1_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (int i = 2; i <= 10; i += 2) {
            System.out.println(i);
        }
	}
}
