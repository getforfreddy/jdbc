/*Create a class called Employee1_2_4 that includes three pieces of information as instance variables—a 
 * first name (type String), a last name (type String) and a monthly salary (double). Your class should 
 * have a constructor that initializes the three instance variables. Provide a set and a get method for 
 * each instance variable. If the monthly salary is not positive, set it to 0.0. Write a test application 
 * named EmployeeTest1_2_4 that demonstrates class Employee’s capabilities. Create two Employee objects and 
 * display each object’s yearly salary. Then give each  Employee a 10% raise and display each 
 * Employee’s yearly salary again.*/

package sample;

public class Employee1_2_4 {
    String firstName;
    String lastName;
    double monthlySalary;

    // Constructor
    public Employee1_2_4(String firstName, String lastName, double monthlySalary) {
        this.firstName = firstName;
        this.lastName = lastName;
        if (monthlySalary > 0) {
            this.monthlySalary = monthlySalary;
        } else {
            this.monthlySalary = 0.0;
        }
    }

    // Getter and Setter for firstName
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Getter and Setter for lastName
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Getter and Setter for monthlySalary
    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        if (monthlySalary > 0) {
            this.monthlySalary = monthlySalary;
        } else {
            this.monthlySalary = 0.0;
        }
    }

    // Method to get yearly salary
    public double getYearlySalary() {
        return monthlySalary * 12;
    }

    // Method to give a 10% raise
    public void giveRaise() {
        this.monthlySalary = this.monthlySalary * 1.1;
    }
}
