//16. Write a program to calculate the sum Harmonic Series.(1 + 1/2 + 1/3 + 1/4 + 1/5 = 2.28 (Approximately))

package sample;

public class Assignment1_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 5;
		double result = 0.0;

		System.out.println("The harmonic series is: ");
		while (num > 0) {
			result = result + (double) 1 / num;
			num--;
			System.out.print(result + ", ");
		}
	}

}
