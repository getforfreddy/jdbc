
/*18. Write a program to  Display Triangle as follow :

1

2 3

4 5 6

7 8 9 10 ...*/

package sample;

public class Assignment1_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int p = 1;
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j < i; j++) {
				System.out.print(p);
				p++;
			}
			System.out.println(); 
		}
	}
}
