/*Create an outer class with a function display, again create another class 
 * inside the outer class named inner with a function called display and call the two 
 * functions in the main class.*/



package sample;

public class Outer1_2_10 {
	
	    
	    // Inner class
	    class Inner {
	        void display() {
	            System.out.println("Inner class display method");
	        }
	    }
	    
	    void display() {
	        System.out.println("Outer class display method");
	    }
	    
	    public static void main(String[] args) {
	        Outer1_2_10 outer1_2_10 = new Outer1_2_10();
	        
	        // Calling outer class display method
	        outer1_2_10.display();
	        
	        // Creating instance of inner class
	        Inner inner = outer1_2_10.new Inner();
	        
	        // Calling inner class display method
	        inner.display();
	    }
	}

