package sample;

public interface A1_2_6 {
	void meth1();
	void meth2();
}
