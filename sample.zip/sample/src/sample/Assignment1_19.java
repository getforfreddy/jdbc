/*
19. Write a program to Display Triangle as follow

0

1 0

0 1 0

1 0 1 0*/

package sample;

public class Assignment1_19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 4;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j <= i; j++) {
				if ((i + j) % 2 == 0) {
					System.out.print("0 ");
				} else {
					System.out.print("1 ");
				}
			}
			System.out.println();
		}
	}

}
