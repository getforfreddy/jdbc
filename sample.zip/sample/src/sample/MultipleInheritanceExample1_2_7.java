//Write a program to give example for multiple inheritance in Java.


package sample;

//Interface 1
interface Animal {
 void eat();
}

//Interface 2
interface Bird {
 void fly();
}

//Implementing both interfaces in a single class
class Sparrow implements Animal, Bird {
 @Override
 public void eat() {
     System.out.println("Sparrow is eating.");
 }

 @Override
 public void fly() {
     System.out.println("Sparrow is flying.");
 }
}

public class MultipleInheritanceExample1_2_7 {
 public static void main(String[] args) {
     Sparrow sparrow = new Sparrow();
     sparrow.eat();
     sparrow.fly();
 }
}

