//10. Swap two numbers
//
//Test Data:
//
//First Number : 25
//
//Second Number: 30

package sample;

public class Assignment10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=25;
		int y=30;

        System.out.println("Before Swap");
        System.out.println("x = " + x);
        System.out.println("y = " + y);
 
        // Swapping using three
        // Variables
        int temp = x;
        x = y;
        y = temp;
 
        System.out.println("After swap");
        System.out.println("x = " + x);
        System.out.println("y = " + y);

	}

}
