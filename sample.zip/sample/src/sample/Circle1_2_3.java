/*A class called circle is designed as shown in the following class diagram. It contains:

    Two private instance variables: radius (of type double) and color (of type String), with default value of 1.0 and "red", respectively.

    Two overloaded constructors;

    Two public methods: getRadius() and getArea().
*/

package sample;

public class Circle1_2_3 {

    // Private instance variables
    private double radius;
    private String color;

    // Default constructor with default values
    public Circle1_2_3() {
        this.radius = 1.0;
        this.color = "red";
    }

    // Overloaded constructor that takes radius and color as parameters
    public Circle1_2_3(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }

    // Public method to get the radius
    public double getRadius() {
        return this.radius;
    }

    // Public method to get the area
    public double getArea() {
        return Math.PI * radius * radius;
    }

    // Main method to test the Circle class
    public static void main(String[] args) {
        // Create a Circle object using the default constructor
        Circle1_2_3 circle1 = new Circle1_2_3();
        System.out.println("Circle 1: Radius = " + circle1.getRadius() + ", Area = " + circle1.getArea());

        // Create a Circle object using the overloaded constructor
        Circle1_2_3 circle2 = new Circle1_2_3(2.5, "blue");
        System.out.println("Circle 2: Radius = " + circle2.getRadius() + ", Area = " + circle2.getArea());
    }
}

