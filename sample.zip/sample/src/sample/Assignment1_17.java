//17. Write a program to  find average of consecutive N Odd no. and Even no.

package sample;

public class Assignment1_17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 10;  
        int evenCount = 0, oddCount = 0, evenSum = 0, oddSum = 0;  
        while (n > 0) {  
             if (n % 2 == 0) {  
                  evenCount++;  
                  evenSum = evenSum + n;  
             } else {  
                  oddCount++;  
                  oddSum = oddSum + n;  
             }  
             n--;  
        }  
        int avgEven, avgOdd;  
        avgEven = evenSum / evenCount;  
        avgOdd = oddSum / oddCount;  
        System.out.println("Average of Even no till 10 is: " + avgEven);  
        System.out.println("Average of Odd no till 10 is: " + avgOdd);  
	}

}
