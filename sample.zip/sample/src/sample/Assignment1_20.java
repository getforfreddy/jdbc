/*
20. Write a program to  Display Triangle as follow

1
2 4
3 6 9
4 8 12 16 ... */

package sample;

import java.util.Iterator;

public class Assignment1_20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		for (int i = 0; i < n; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(i*j+" ");
			}
			System.out.println();
	}

}}
