//2.Write a program to  Compare Two Numbers Java Example

package sample;

public class Assignment1_2 {

	public static void main(String[] args) {
		int num1= 5;
		int num2= 3;
		if (num1>num2) {
			System.out.println("number 1 is grater");
			
		} else {
System.out.println("number 2 is grater");
		}
	}

}
