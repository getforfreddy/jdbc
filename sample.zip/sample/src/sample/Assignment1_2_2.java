/*There is a car, which has attributes model and price, and the car 
 * has functionalities start, stop and move. Also, there is a driver, 
 * having attributes name and age, and the behaviour drive.

Model the classes Car and Driver. You need to take care of the accessibility of 
the attributes from outside the class for the best design.
*/

package sample;

 class Car {
    // Attributes (fields)
    private String model;
    private double price;

    // Constructor
    public Car(String model, double price) {
        this.model = model;
        this.price = price;
    }

    // Getter for model
    public String getModel() {
        return model;
    }

    // Setter for model
    public void setModel(String model) {
        this.model = model;
    }

    // Getter for price
    public double getPrice() {
        return price;
    }

    // Setter for price
    public void setPrice(double price) {
        this.price = price;
    }

    // Behavior: start
    public void start() {
        System.out.println("The car has started.");
    }

    // Behavior: stop
    public void stop() {
        System.out.println("The car has stopped.");
    }

    // Behavior: move
    public void move() {
        System.out.println("The car is moving.");
    }
}

 class Driver {
    // Attributes (fields)
    private String name;
    private int age;

    // Constructor
    public Driver(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for age
    public int getAge() {
        return age;
    }

    // Setter for age
    public void setAge(int age) {
        this.age = age;
    }

    // Behavior: drive
    public void drive(Car car) {
        car.start();
        car.move();
        System.out.println(name + " is driving the car.");
        car.stop();
    }
}

public class Assignment1_2_2 {
    public static void main(String[] args) {
        // Creating a Car object
        Car car = new Car("Toyota Camry", 30000);

        // Creating a Driver object
        Driver driver = new Driver("Alice", 30);

        // Driver drives the car
        driver.drive(car);
    }
}

