///3.Write a Java program to divide two numbers and print on the screen.
//Test Data :
//50/3


package sample;


public class Assignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(50/3);

	}

}
