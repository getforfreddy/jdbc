//15.Write a program to find whether given no. is Armstrong or not.

package sample;

public class Assignment1_15 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = 372, originalNumber, remainder, result = 0;

		originalNumber = number;
		while (originalNumber != 0) {
			remainder = originalNumber % 10;
			result += Math.pow(remainder, 3);
			originalNumber /= 10;
		}
		if (result == number)
			System.out.println(number + " is an Armstrong number.");
		else
			System.out.println(number + " is not an Armstrong number.");
	}
}
