//6.d.Write a program to  generate following pyramid or triangle like  given below using for loop.

package sample;

public class Assignment1_6_d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j);
            }
            System.out.println(); // Move to the next line after each row
        }
	}

}
