//1.Write a Java program to print 'Hello' on screen and then print your name on a separate line. 


package sample;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		System.out.println("Alexandra Abramov");
		
	}

}
