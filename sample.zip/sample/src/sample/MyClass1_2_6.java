package sample;

public class MyClass1_2_6 implements A1_2_6{

	 // Implementing meth1
    @Override
    public void meth1() {
        System.out.println("meth1 implementation in MyClass");
    }

    // Implementing meth2
    @Override
    public void meth2() {
        System.out.println("meth2 implementation in MyClass");
    }

    public static void main(String[] args) {
        MyClass1_2_6 myClass = new MyClass1_2_6();
        myClass.meth1(); 
        myClass.meth2(); 
    }

}
