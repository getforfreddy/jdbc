//2.Write a Java program to print the sum of two numbers.
//Test Data:
//74 + 36 

package sample;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(74+36);

	}

}
