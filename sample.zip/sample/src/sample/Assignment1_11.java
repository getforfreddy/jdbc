//11. Write a program to find sum of all integers greater than 100 and less than 200 that are divisible by 7.

package sample;

public class Assignment1_11 {

	public static void main(String[] args) {
		 int sum = 0;
		 for (int i =100;i<200; i++) {
	            if (i%7 == 0) {
	                sum += i; 
	                System.out.println(i);
	            }
		 }
	System.out.println("Sum of numbers divisible by 7 between 100 and 200: " + sum);
	}
}
