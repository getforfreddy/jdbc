//13.Write a program to Swap the value of 2 variables.

package sample;

public class Assignment1_13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=10;
		int num2=20;
		int temp=0;
		System.out.println("Before swap first number is: "+num1);
		System.out.println("Before swap second number is: "+num2);
		temp=num1;
		num1=num2;
		num2=temp;
		System.out.println("After swap first number is: "+num1);
		System.out.println("Afterswap second number is: "+num2);
	}

}
