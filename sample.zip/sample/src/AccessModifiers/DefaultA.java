package AccessModifiers;

public class DefaultA {
	void msg() {
		System.out.println("Entering...");
	}
}
