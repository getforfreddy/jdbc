package AccessModifiers;

public class Default {
	public void main(String[] agrs) {
		 DefaultA a = new DefaultA();
		a.msg();
	}

}
