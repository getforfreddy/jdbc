package AccessModifiers;

public class protectedA {
	protected void mrng() {
		System.out.println("Good Morning...");
	}
}
