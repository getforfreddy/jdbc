package AccessModifiers;

public class PublicA {
public void Evening() {
	System.out.println("Good Eveining...");
}
}
