package AccessModifiers;

class Protected extends protectedA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Protected protected1=new Protected();
		protected1.mrng();
	}

}
