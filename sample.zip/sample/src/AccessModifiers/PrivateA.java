package AccessModifiers;

public class PrivateA {
	private int tickets=5;//only can access in Private class.
 void tik() {
		System.out.println("Clear the tickets");
		System.out.println("Number of tickets is:"+tickets);
	}
}
