package AccessModifiers;
//import
public class Public {
	 public static void main(String args[]){  
		   PublicA a= new PublicA();
		   a.Evening();
}}
