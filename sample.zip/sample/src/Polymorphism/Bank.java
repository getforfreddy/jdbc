//package Polymorphism;
//
//class Bank {
//	float getRateOfIntrest() {
//		return 0;
//	}
//
//}
// class SBI extends Bank{
//	 float getRateOfIntrest() {
//		 return 8.4f;
//	 }
// }
// class ICICI extends Bank{
//	 float getRateOfIntrest() {
//		 return 7.3f;
//	 }
// }
//class AXIS extends Bank{
//	float getRateOfInterst() {
//		return 9.7f;
//	}
//}
//class BankIntrest {
//	public void Main(String[]args) {
//		Bank bank;
//		bank=new SBI();
//		System.out.println("SBI Rate of Interest:"+bank.getRateOfIntrest());
//		bank=new ICICI();
//		System.out.println("ICICi Rate of Interest:"+bank.getRateOfIntrest());
//		bank=new AXIS();
//		System.out.println("AXIS Rate of Interest:"+bank.getRateOfIntrest());
//	}
//}

package Polymorphism;

class Bank {
    float getRateOfIntrest() {
        return 0;
    }
}

class SBI extends Bank {
    float getRateOfIntrest() {
        return 8.4f;
    }
}

class ICICI extends Bank {
    float getRateOfIntrest() {
        return 7.3f;
    }
}

class AXIS extends Bank {
    float getRateOfIntrest() {
        return 9.7f;
    }
}

class BankIntrest {
    public static void main(String[] args) {
        Bank bank;

        bank = new SBI();
        System.out.println("SBI Rate of Interest: " + bank.getRateOfIntrest());

        bank = new ICICI();
        System.out.println("ICICI Rate of Interest: " + bank.getRateOfIntrest());

        bank = new AXIS();
        System.out.println("AXIS Rate of Interest: " + bank.getRateOfIntrest());
    }
}
