
class RunTimeBike {
	void Bike() {
		System.out.println("Bike is running");
	}

}
