package ExceptionHandling;

//Define the InsufficientFundsException
class InsufficientFundsExceptionAssignment extends Exception {
 public InsufficientFundsExceptionAssignment(String message) {
     super(message);
 }
}

//Define the CheckingAccount class
class CheckingAccount {
 private double balance;

 public CheckingAccount(double initialBalance) {
     this.balance = initialBalance;
 }

 public void deposit(double amount) {
     if (amount > 0) {
         balance += amount;
     } else {
         throw new IllegalArgumentException("Deposit amount must be positive.");
     }
 }

 public void withdraw(double amount) throws InsufficientFundsExceptionAssignment {
     if (amount > balance) {
         throw new InsufficientFundsExceptionAssignment("Cannot withdraw " + amount + ". Available balance is " + balance + ".");
     } else if (amount <= 0) {
         throw new IllegalArgumentException("Withdrawal amount must be positive.");
     } else {
         balance -= amount;
     }
 }

 public double getBalance() {
     return balance;
 }

 public static void main(String[] args) {
     try {
         CheckingAccount account = new CheckingAccount(100.0);  // Initialize account with $100
         account.deposit(50.0);                                // Deposit $50
         System.out.println("Balance after deposit: $" + account.getBalance());  // Expected balance: $150

         account.withdraw(200.0);                              // Attempt to withdraw $200
     } catch (InsufficientFundsExceptionAssignment e) {
         System.out.println(e.getMessage());
     } catch (IllegalArgumentException e) {
         System.out.println(e.getMessage());
     }

     // Check the final balance
     CheckingAccount account = new CheckingAccount(100.0);  // Initialize account with $100
     account.deposit(50.0);                                // Deposit $50
     System.out.println("Final balance: $" + account.getBalance());  // Expected balance: $150 if exception occurred
 }
}

