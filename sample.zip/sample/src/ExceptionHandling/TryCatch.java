package ExceptionHandling;

public class TryCatch {
public static void mani(String []args) {
	try {
		int a= 50/0;
	} catch (ArithmeticException e) {
		// TODO: handle exception
		System.out.println(e);
	}
	System.out.println("rest of the code. ");
}
}
