//package ExceptionHandling;
//
//import java.io.IOException;
//
//class Parent{
//	void msg() {
//		System.out.println("Parent method");
//	}
//}
//public class SuperClassMethodException extends Parent{
//	void msg()throws IOException{
//		System.out.println("TestException Child");
//	}
//	public static void main(String args[]) {
//		Parent pr=new Parent();
//		pr.msg();
//	}
//
//}
