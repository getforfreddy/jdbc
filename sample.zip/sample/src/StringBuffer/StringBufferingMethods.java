package StringBuffer;

public class StringBufferingMethods {

	public static void main(String[] args) {
		StringBuffer name = new StringBuffer("Freddy ");

		name.append("Nixal");
		System.out.println(name);
		name.insert(6, "Nixon");
		System.out.println(name);
		name.replace(5, 11, "Nison");
		System.out.println(name);
		name.delete(5, 11);
		System.out.println(name);
		name.reverse();
		System.out.println(name);
		name.reverse();
		System.out.println(name);
		System.out.println(name.capacity());
		StringBuffer names=new StringBuffer("Karthik, Maneesha, Renju, Sreelakshmi, Jiji, Aleena, Divin, Ganesh, Jo, Ashin, Vaishakh, Lijo");
		names.ensureCapacity(500);
		System.out.println(names);
//		name.charAt(10);
//		System.out.println(name);
	}
}
