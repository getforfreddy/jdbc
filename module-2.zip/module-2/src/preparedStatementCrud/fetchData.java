package preparedStatementCrud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dbconnection.DBConnection;

public class fetchData {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection("jdbc:mysql://"+DBConnection.HOST_ADDERSS+":"+DBConnection.PORT+"/"+DBConnection.DATABASE,DBConnection.USERNAME,DBConnection.PASSWORD);
			PreparedStatement statement= connection.prepareStatement("select * from person");
			ResultSet resultSet=statement.executeQuery();
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1)+" "+resultSet.getString(2));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
