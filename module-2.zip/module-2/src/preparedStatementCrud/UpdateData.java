package preparedStatementCrud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import dbconnection.DBConnection;

public class UpdateData {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://"+DBConnection.HOST_ADDERSS+":"+DBConnection.PORT+"/"+DBConnection.DATABASE,DBConnection.USERNAME,DBConnection.PASSWORD);
			PreparedStatement statement=conn.prepareStatement("update person set name=? where id=?");
			statement.setString(1,"Joseph");
			statement.setInt(2,11);
			int added=statement.executeUpdate();
			System.out.println(added);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
