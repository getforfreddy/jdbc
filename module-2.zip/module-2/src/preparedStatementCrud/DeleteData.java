package preparedStatementCrud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import dbconnection.DBConnection;

public class DeleteData {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection("jdbc:mysql://"+DBConnection.HOST_ADDERSS+":"+DBConnection.PORT+"/"+DBConnection.DATABASE,DBConnection.USERNAME,DBConnection.PASSWORD);
			PreparedStatement statement=connection.prepareStatement("delete from person where id=?");
			statement.setInt(1, 11);
			int del=statement.executeUpdate();
			System.out.println(del);
		} catch (Exception e) {
			System.out.println(e);
		}
		

	}

}
