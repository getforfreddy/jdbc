package preparedStatementCrud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import dbconnection.DBConnection;

public class InsertData {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://"+ DBConnection.HOST_ADDERSS +":"+DBConnection.PORT+"/"+DBConnection.DATABASE,DBConnection.USERNAME,DBConnection.PASSWORD);
			PreparedStatement statement=connection.prepareStatement("insert into person values(?,?)");
			statement.setInt(1,13);
			statement.setString(2,"Kiran");
			int add=statement.executeUpdate();
			System.out.println(add);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
