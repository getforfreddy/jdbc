package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import dbconnection.DBConnection;

public class InsertRecord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://" + DBConnection.HOST_ADDERSS + ":" + DBConnection.PORT + "/" + DBConnection.DATABASE,
					DBConnection.USERNAME, DBConnection.PASSWORD);
			
			Statement stmt= conn.createStatement();
			int result= stmt.executeUpdate("insert into person values(10, 'Jim')");
			System.out.println(result+" row inserted");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
