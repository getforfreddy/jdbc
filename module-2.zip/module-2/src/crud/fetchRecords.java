package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


import dbconnection.DBConnection;

public class fetchRecords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://" + DBConnection.HOST_ADDERSS + ":" + DBConnection.PORT + "/" + DBConnection.DATABASE,
					DBConnection.USERNAME, DBConnection.PASSWORD);
			Statement stem = conn.createStatement();
	ResultSet resultSet=
			stem.executeQuery("select * from person");
	
	while (resultSet.next()) {
		System.out.println(resultSet.getInt("id")+ " "+resultSet.getString("name"));
	}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
