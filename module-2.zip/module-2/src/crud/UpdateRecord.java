package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import dbconnection.DBConnection;

public class UpdateRecord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://" + DBConnection.HOST_ADDERSS + ":" + DBConnection.PORT + "/" + DBConnection.DATABASE,
					DBConnection.USERNAME, DBConnection.PASSWORD);
			Statement stmt=conn.createStatement();
			int update=stmt.executeUpdate("update person set name='Freddy' where id=10");
			System.out.println(update+" is updaterd");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
