package assignmentCurd;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import dbconnection.DBConnection;

public class EmployeeDAO {

    public void insertEmployee(int id, String name, int age, String department) {
        String query = "INSERT INTO emplyee (id, name, age, department) VALUES (" + id + ", '" + name + "', " + age + ", '" + department + "')";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(query);
            System.out.println("Employee inserted successfully.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        String query = "SELECT * FROM emplyee";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String department = rs.getString("department");
                employees.add(new Employee(id, name, age, department));
                System.out.println("Employee Id :"+id+" Name :"+name+" Age :"+age+" Department :"+department);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return employees;
    }

    public void updateEmployee(int id, String name, int age, String department) {
        String query = "UPDATE emplyee SET name = '" + name + "', age = " + age + ", department = '" + department + "' WHERE id = " + id;

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(query);
            System.out.println("Employee updated successfully.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void deleteEmployee(int id) {
        String query = "DELETE FROM emplyee WHERE id = " + id;

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(query);
            System.out.println("Employee deleted successfully.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        EmployeeDAO employeeDAO = new EmployeeDAO();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Insert Employee");
            System.out.println("2. View All Employees");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Employee ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Employee Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Employee Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Employee Department: ");
                    String department = scanner.nextLine();
                    employeeDAO.insertEmployee(id, name, age, department);
                    break;
                case 2:
                    employeeDAO.getAllEmployees();
                    break;
                case 3:
                    System.out.print("Enter Employee ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter new Employee Name: ");
                    String updateName = scanner.nextLine();
                    System.out.print("Enter new Employee Age: ");
                    int updateAge = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter new Employee Department: ");
                    String updateDepartment = scanner.nextLine();
                    employeeDAO.updateEmployee(updateId, updateName, updateAge, updateDepartment);
                    break;
                case 4:
                    System.out.print("Enter Employee ID to delete: ");
                    int deleteId = scanner.nextInt();
                    employeeDAO.deleteEmployee(deleteId);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
