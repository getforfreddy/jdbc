package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	public static final String HOST_ADDERSS= "202.146.192.27";
	public static final String PORT= "3306";
	public static final String DATABASE= "javadb_180";
	public static final String USERNAME= "javadb_180";
	public static final String PASSWORD= "J_AVadB_180";
	
	static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
	
	public static Connection getConnection() throws Exception {
        String url = "jdbc:mysql://" + HOST_ADDERSS + ":" + PORT + "/" + DATABASE;
        return DriverManager.getConnection(url, USERNAME, PASSWORD);
    }
	
}
