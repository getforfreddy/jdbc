package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	public static final String HOST_ADDERSS = "202.146.192.27";
	public static final String PORT = "3306";
	public static final String DATABASE = "javadb_180";
	public static final String USERNAME = "javadb_180";
	public static final String PASSWORD = "J_AVadB_180";

	private static final String URL = "jdbc:mysql://" + HOST_ADDERSS + ":" + PORT + "/" + DATABASE;

	public static Connection getConnection() throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");

		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found: " + e.getMessage());
		}
		return DriverManager.getConnection(URL, USERNAME, PASSWORD);
	}

}
